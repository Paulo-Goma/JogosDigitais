import pygame
import sys

def save_score(player_name, score):
    with open("score.txt", "a") as file:
        file.write(f"{player_name}: {score}\n")

def game_over(score):
    pygame.init()
    screen = pygame.display.set_mode((400, 300))
    font = pygame.font.Font(None, 36)
    clock = pygame.time.Clock()

    player_name = ""
    input_active = True

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if player_name:
                        save_score(player_name, score)
                        pygame.quit()
                        sys.exit()
                    else:
                        input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    player_name = player_name[:-1]
                else:
                    player_name += event.unicode

        screen.fill((255, 255, 255))
        text = font.render("Enter your name: " + player_name, True, (0, 0, 0))
        screen.blit(text, (50, 50))
        pygame.display.flip()
        clock.tick(60)

score = 1000
game_over(score)

